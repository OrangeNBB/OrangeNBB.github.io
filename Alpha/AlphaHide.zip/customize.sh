

echo "\n=========================================="
echo "      欢迎使用Alpha隐藏工具箱"
echo "==========================================\n"
echo "\n=========================================="
echo "      接下来将为您安装隐藏模块"
echo "==========================================\n"
echo "\n=========================================="
echo "    请确保您的面具为Alpha面具，否则无法发挥隐藏效果"
echo "==========================================\n"
echo "- Magisk 版本: $MAGISK_VER_CODE\n\n\n\n"

sleep 4

    echo "开始刷入"
    echo "- 正在刷入[Shamiko-v1.2.5-414-release.zip]"
    echo "*********************************************"
    magisk --install-module "$MODPATH/EnvAlpha/1.zip"
    # ②
    echo "- 正在刷入[Tricky-Store-v1.3.0-180-8acfa57-release.zip]"
    echo "*********************************************"
    magisk --install-module "$MODPATH/EnvAlpha/2.zip"

    # ⑨
    echo "- 正在刷入[Zygisk MapHide.zip]"
    echo "*********************************************"
    magisk --install-module "$MODPATH/EnvAlpha/9.zip"

    # ④
    echo "- 正在刷入[Zygisk-Next-1.2.9-521-e73dbfc-release.zip]"
    echo "*********************************************"
    magisk --install-module "$MODPATH/EnvAlpha/4.zip"

    # ⑤
    echo "- 正在刷入[PlayIntegrityFix_v19.2-TEST.zip]"
    echo "*********************************************"
    magisk --install-module "$MODPATH/EnvAlpha/5.zip"

    # ⑥
    echo "- 正在刷入[LSPosed-v1.10.1-7165-zygisk-release]"
    echo "*********************************************"
    magisk --install-module "$MODPATH/EnvAlpha/6.zip"

    sleep 1
    echo "- 正在尝试设置shamiko模块白名单模式"
    echo "*********************************************"
    
    touch /data/adb/shamiko/whitelist
    

# ==============================================
# 后续操作（文件移动、APK安装等）（其余逻辑保持不变）
# ==============================================
# 移动keybox.xml到指定目录（更新时间7.23）
echo "- 移动模块内置最新keybox.xml"
echo "*********************************************"
mv -f "$MODPATH/EnvAlpha/keybox.xml" "/data/adb/tricky_store/"

# 安装"隐藏应用列表"HMA
echo "- 安装模块内置'隐藏应用列表'app"
echo "*********************************************"
# 解压APK到临时目录（不保留原目录结构）
unzip -jo "$ZIPFILE" 'EnvAlpha/hma.apk' -d /data/local/tmp &>/dev/null
# 覆盖安装APK
pm install -r /data/local/tmp/hma.apk &>/dev/null
# 检测HMA安装结果
if pm list packages | grep -q "com.tsng.hidemyapplist"; then
    echo "- HMA安装完成"
else
    echo "- HMA安装失败"
fi
# 清理临时文件

# 移动config.json到Download  v2.4尝试修复
echo "- 移动模块内置config.json"
echo "*********************************************"
unzip -jo "$ZIPFILE" 'EnvAlpha/config.json' -d /data/local/tmp &>/dev/null
mv -f "/data/local/tmp/config.json" "/sdcard/Download"
rm -f /data/local/tmp/config.json

# ==============================================
# 音量键选择：刷入"游戏线程优化"模块（7.zip）
# ==============================================
echo "- 是否刷入'游戏线程优化'模块?"
echo "- 按音量键+刷入"
echo "- 按音量键-跳过"
# 5秒超时检测逻辑
TIMEOUT=5  # 超时时间（秒）
KEY_TIMEOUT=false  # 超时标志
echo "- 5秒后超时将自动跳过..."
start=$(date +%s)  # 记录开始时间
# 循环检测按键或超时
while [ $(( $(date +%s) - start )) -lt $TIMEOUT ]; do
    # 获取音量键输入（兼容不同设备的输入检测）
    key=$(dumpsys input 2>/dev/null | awk '/KEY_VOLUME/{print $2;exit}')
    [ -z "$key" ] && key=$(getevent -qlc 1 2>/dev/null | awk '{print $3}' | grep 'KEY_' | head -n1)
    
    # 检测到音量+，刷入模块
    if [ "$key" = "KEY_VOLUMEUP" ]; then
        # 根据环境选择安装命令
        if [[ "$KSU" == "true" ]]; then
            ksud module install "$MODPATH/EnvAlpha/8.zip"
        elif [[ "$APATCH" == "true" ]]; then
            apd module install "$MODPATH/EnvAlpha/8.zip"
        else
            magisk --install-module "$MODPATH/EnvAlpha/8.zip"  # 直接使用正确的Magisk命令
        fi
        echo "- 已刷入'游戏线程优化'模块"
        break
    fi
    sleep 0.2  # 短暂延迟，减少资源占用
done
# 超时未操作，自动跳过
if [ $(( $(date +%s) - start )) -ge $TIMEOUT ]; then
    echo "⏳ 已超时，自动跳过刷入"
fi


# ==============================================
# 完成提示
# ==============================================
echo ""
echo "- 刷入完成😋"
echo "- 隐藏应用列表config.json导入后请自行清除残留"
echo "- PIF模块需手动执行(需要魔法)"
