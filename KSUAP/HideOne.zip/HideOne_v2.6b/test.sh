#!/system/bin/sh
echo "=== 测试脚本运行中 ==="
echo "当前时间：$(date)"
echo "test测试完成"
echo "=== 测试脚本结束 ==="
