if [ -f "/data/adb/shamiko/whitelist" ]; then rm -f "/data/adb/shamiko/whitelist"; else touch "/data/adb/shamiko/whitelist"; fi
echo "模式切换完成"
