sed -i 's/^description=.*/description=状态:模块停止运行❌本模块可全自动添加TS模块包名列表，支持添加白名单及额外包名默认添加3方应用包名/' module.prop
